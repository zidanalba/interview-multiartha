from .authentication import auth_ns
from .user import user_ns